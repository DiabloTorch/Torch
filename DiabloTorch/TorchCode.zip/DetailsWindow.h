/********   ********   ********/
/*      DetailsWindow.h       */
/********   ********   ********/
/*          9/7/2018          */
/********   ********   ********/
/*           Tiron            */
/********   ********   ********/
// http://tristr.am/
// https://freshmeat-blog.de.tl/

#ifndef DETAILS_H
#define DETAILS_H

#include "Window.h"

class DetailsClass : public Window
{
private:
//	Window ThisWindow;

public:
	DetailsClass();
	~DetailsClass();

	void Draw();
};

extern DetailsClass MonsterDetails;

#endif